# semester-project-incidentreporter
semester-project-incidentreporter created by GitHub Classroom

Created as a semester project for CS 304, Incident Reporter protects students 
while allowing proper actions to be taken to ensure a safe learning environment for all.
In reporting incidents, students are given agency in determining the level of 
anonyminity they are comfortable with. There are many situations where a student 
might not feel comfortable identifying themselves, 
given the power professor hold over students.
